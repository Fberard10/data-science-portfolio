# Local LLM Chatbot

Runs Meta's Llama 3.2 (1B Instruct) locally using HuggingFace Transformers and PyTorch. No API calls — inference happens entirely on your machine.

## Notebooks

| Notebook | Description |
|---|---|
| `llm_inference.ipynb` | Basic Llama 3.2 pipeline setup; single-turn prompt/response |
| `chatbot.ipynb` | Stateful multi-turn chatbot with full conversation context management; runs interactively in terminal |

## How It Works

Both notebooks use HuggingFace's `pipeline` abstraction to load Llama 3.2-1B-Instruct. The chatbot notebook maintains a running message list (system + user + assistant turns) and passes the full context window on each call, enabling coherent multi-turn conversation.

```python
context = [{'role': 'system', 'content': 'You are a helpful assistant.'}]

while True:
    user_input = input('> ')
    context.append({'role': 'user', 'content': user_input})
    response = ai(context, max_new_tokens=256)
    context = response[-1]['generated_text']  # carry full history forward
```

## Requirements

- HuggingFace account with access to `meta-llama/Llama-3.2-1B-Instruct`
- HuggingFace token stored in a `.env` file as `HUGGINGFACE_TOKEN`
- GPU recommended (CUDA); falls back to CPU automatically

## Setup

```bash
conda create -n llm transformers torch python-dotenv ipykernel python -c conda-forge -y
conda activate llm
```

Create a `.env` file in this directory:
```
HUGGINGFACE_TOKEN=your_token_here
```
