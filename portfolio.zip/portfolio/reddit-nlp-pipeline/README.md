# Reddit NLP Pipeline

End-to-end NLP pipeline applied to Reddit community data. Covers the full workflow from raw scraped data through sentiment scoring, clustering, and topic modeling.

## Notebooks (run in order)

| Notebook | Description |
|---|---|
| `data_wrangling.ipynb` | Load and explore scraped Reddit data; basic statistics and top-post analysis |
| `date_filtering.ipynb` | Date parsing, range filtering, and structured CSV export |
| `data_mining.ipynb` | Post-volume time series analysis; spike detection and top-scoring post identification |
| `sentiment_analysis.ipynb` | VADER sentiment scoring on iPhone 16 Reddit reviews; top positive/negative post extraction and histogram visualization |
| `clustering.ipynb` | Document-term matrix → TSNE dimensionality reduction → KMeans and DBSCAN clustering with interactive scatter plot |
| `topic_modeling.ipynb` | LDA topic modeling with stopword removal; top-5 word extraction per topic |

## Datasets

Notebooks expect scraped Reddit CSV files in the working directory. Each CSV contains columns: `date`, `author`, `title`, `text`, `score`, `parent_id`, `reply`.

Reddit data can be collected using a scraper pointed at any subreddit of your choice. The analyses here were applied to: r/datascience, r/SupermanAndLois, and an iPhone 16 product review thread.

## Stack

- **pandas** — data wrangling and filtering
- **vaderSentiment** — rule-based sentiment analysis
- **scikit-learn** — CountVectorizer, TSNE, KMeans, DBSCAN, LDA
- **nltk** — stopword removal
- **Plotly** — interactive charts and scatter plots

## Setup

```bash
conda create -n nlp pandas scikit-learn numpy nltk plotly ipykernel nbformat python -c conda-forge -y
conda activate nlp
pip install vaderSentiment
nltk.download('stopwords')  # run once inside a notebook
```
