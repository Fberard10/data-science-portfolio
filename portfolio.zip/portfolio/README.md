# Data Science & NLP Portfolio

Python projects covering data wrangling, natural language processing, and machine learning. Built using pandas, scikit-learn, HuggingFace Transformers, and Plotly.

---

## Projects

### 1. [Reddit NLP Pipeline](./reddit-nlp-pipeline/)
End-to-end NLP analysis of Reddit communities — scraping, cleaning, sentiment scoring, clustering, and topic modeling across multiple datasets including r/datascience and iPhone 16 product reviews.

**Stack:** pandas · VADER · scikit-learn · TSNE · KMeans · DBSCAN · LDA · Plotly

---

### 2. [Local LLM Chatbot](./local-llm-chatbot/)
Runs Meta's Llama 3.2 (1B) locally via HuggingFace Transformers. Includes a stateful multi-turn chatbot with full conversation context management.

**Stack:** HuggingFace Transformers · PyTorch · Llama 3.2

---

### 3. [Stock Price Analysis](./stock-analysis/)
Comparative equity price visualization for Tesla and CrowdStrike over summer 2024. Includes data cleaning, date filtering, and interactive charting.

**Stack:** pandas · Plotly

---

## Setup

```bash
conda create -n portfolio pandas scikit-learn numpy nltk plotly transformers torch ipykernel python -c conda-forge -y
conda activate portfolio
pip install vaderSentiment
```

A HuggingFace account and access token are required for the LLM notebooks (`local-llm-chatbot/`).
